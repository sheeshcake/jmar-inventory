<?php
    include "core.php";
    guard();
?>