<td class="item-data" colspan="7" style="display:none">
    <div class="card">
        <div class="d-flex">
            <div class="p-2">
                <img src="data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22286%22%20height%3D%22180%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20286%20180%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_175d4a23700%20text%20%7B%20fill%3Argba(255%2C255%2C255%2C.75)%3Bfont-weight%3Anormal%3Bfont-family%3AHelvetica%2C%20monospace%3Bfont-size%3A14pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_175d4a23700%22%3E%3Crect%20width%3D%22286%22%20height%3D%22180%22%20fill%3D%22%23777%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%2299.1171875%22%20y%3D%2296.3%22%3EImage%20cap%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E" alt="">
                <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
            </div>
            <div class="mr-auto p-2 w-100">
                <table class="table w-100">
                    <tr>
                        <th>Item Name:</th>
                        <td contenteditable>Bulb1</td>
                    </tr>
                    <tr>
                        <th>Brand:</th>
                        <td contenteditable>Firefly</td>
                    </tr>
                    <tr>
                        <th>Category:</th>
                        <td contenteditable>Bulbs</td>
                    </tr>
                    <tr>
                        <th>Price:</th>
                        <td contenteditable>69</td>
                    </tr>
                    <tr>
                        <th>Stock:</th>
                        <td contenteditable>100</td>
                    </tr>
                    <tr>
                        <th>Total Price:</th>
                        <td contenteditable>6,900</td>
                    </tr>
                </table>
                <button class="btn btn-primary">Update</button>
                <button class="btn btn-danger">Delete</button>
            </div>
        </div>
    </div>
</td>