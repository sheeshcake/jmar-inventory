<?php
    include "../controller/connect.php";
    session_start();
    if(isset($_POST["id"])){
        $sql = "SELECT * FROM ";
    }
?>