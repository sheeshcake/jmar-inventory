<?php
    include "core.php";
    guard(true);
?>