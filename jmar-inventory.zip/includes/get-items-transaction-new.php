<tr>
    <td colspan="4">Loading Items..</td>
</tr>