<tr>
    <td colspan="5">Loading Items..</td>
</tr>