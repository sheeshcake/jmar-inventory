<?php
    include "../controller/core.php";
    guard(true);
?>