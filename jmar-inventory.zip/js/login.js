
$(document).ready(function() {
    setTimeout(function() {
        $("#lgn-alert").fadeOut(300);
    }, (3000));
});